﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Interfaces
{
    public interface IModelCity<T> 
    {
        Task<T> GetWeather();
        string CallCity(string city);
    }
}
