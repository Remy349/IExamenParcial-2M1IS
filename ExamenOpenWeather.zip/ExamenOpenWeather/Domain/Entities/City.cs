﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Entities
{
    public class City
    {
        public class Coord
        {
            public string Lon { get; set; }
            public string Lat { get; set; }
        }

        public class Weather
        {
            public string Main { get; set; }
            public string Description { get; set; }
        }

        public class Main
        {
            public double Temp { get; set; }
            public double Temp_min { get; set; }
            public double Temp_max { get; set; }
            public double Pressure { get; set; }
            public double Humidity { get; set; }
        }

        public class Wind
        {
            public string Speed { get; set; }
            public string Deg { get; set; }
        }

        public class Sys
        {
            public string Country { get; set; }
            public long Sunrise { get; set; }
            public long Sunset { get; set; }
        }

        public class Clouds
        {
            public string All { get; set; }
        }

        public class Root
        {
            public Coord coord { get; set; }
            public List<Weather> weathers { get; set; }
            public Main main { get; set; }
            public Wind wind { get; set; }
            public Sys sys { get; set; }
            public string dt { get; set; }
            public string name { get; set; }
        }
    }
}
