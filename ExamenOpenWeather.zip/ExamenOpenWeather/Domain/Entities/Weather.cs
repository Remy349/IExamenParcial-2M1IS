﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Entities
{
    public class Weather
    {
        public class weather
        {
            public string Main { get; set; }
            public string Description { get; set; }
        }

        public class Hourly
        {
            public string Dt { get; set; }
            public string Pressure { get; set; }
            public string Humidity { get; set; }
            public string Temp_min { get; set; }
            public string Temp_max { get; set; }
            public string Temp { get; set; }
            public string Wind_speed { get; set; }
        }
      
        public class Root
        {
            public List<weather> weathers { get; set; }
            public List<Hourly> hourlies { get; set; }
            public string name { get; set; }
            public string lon { get; set; }
            public string lat { get; set; }
            public string timezone { get; set; }
        }
    }
}
