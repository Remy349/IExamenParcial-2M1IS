﻿using Common;
using Domain.Entities;
using Domain.Interfaces;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Infraestructure.Repository
{
    public class RepositoryApi : IModelCity<City.Root>, IModelWeather<Weather.Root>
    {
        protected string url = String.Empty;
        protected string city = String.Empty;
        protected string lat = String.Empty;
        protected string lon = String.Empty;
        protected string dt = String.Empty;
        public static List<City.Root> allCity = new List<City.Root>();

        public async Task<City.Root> GetWeather()
        {
            try
            {
                using (WebClient web = new WebClient())
                {
                    url = string.Format($"{AppSettings.ApiUrl}{city}&appid={ AppSettings.Token}&lang=es");
                    var Json = web.DownloadString(url);
                    City.Root info = JsonConvert.DeserializeObject<City.Root>(Json);
                    allCity.Add(info);
                    return await Task.FromResult(info);
                }
            }
            catch (IOException)
            {
                throw new NullReferenceException("Error");
            }
        }

        public async Task<Weather.Root> GetForecast()
        {
            allCity.ForEach(x => lat = x.coord.Lat);
            allCity.ForEach(x => lon = x.coord.Lon);
            allCity.ForEach(x => dt = x.dt);

            try
            {
                using (WebClient web = new WebClient())
                {
                    url = string.Format($"{AppSettings.ApiUrlOneCall}lat={lat}&lon={lon}&dt={dt}&appid={ AppSettings.Token}");
                    var Json = web.DownloadString(url);
                    // var info = JsonConvert.DeserializeObject<Weather.Root>(Json);
                    Weather.Root info = JsonConvert.DeserializeObject<Weather.Root>(Json);
                    return await Task.FromResult(info);
                }
            }
            catch (IOException)
            {
                throw new NullReferenceException("Error");
            }
        }

        public string CallCity(string city)
        {
            return this.city = city;
        }
    }
}
