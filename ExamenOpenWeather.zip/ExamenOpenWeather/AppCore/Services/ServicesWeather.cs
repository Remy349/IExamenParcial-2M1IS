﻿using AppCore.IServices;
using Domain.Entities;
using Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppCore.Services
{
    public class ServicesWeather : IServicesWeather<Weather.Root>
    {
        private IModelWeather<Weather.Root> model;

        public ServicesWeather(IModelWeather<Weather.Root> model)
        {
            this.model = model;
        }

        public Task<Weather.Root> GetForecast()
        {
            return model.GetForecast();
        }
    }
}
