﻿using AppCore.IServices;
using Domain.Entities;
using Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppCore.Services
{
    public class ServicesCity : IServicesCity<City.Root>
    {
        protected IModelCity<City.Root> model;

        public ServicesCity(IModelCity<City.Root> model)
        {
            this.model = model;
        }

        public Task<City.Root> GetWeather()
        {
            return model.GetWeather();
        }

        public string CallCity(string city)
        {
            return model.CallCity(city);
        }
    }
}
